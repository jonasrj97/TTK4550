
# import required module
from PIL import Image
import os

# classes:
#   0: copepod_calanoid
#   1: acantharia_protist
#   2: appendicularian_s_shape
#   3: chaetognath_non_sagitta
#   4: echinoderm_larva_seastar_brachiolaria
#   5: trichodesmium_bowtie
#   6: tunicate_doliolid_nurse

# initial values

max_width = 0
max_height = 0
directory_list = ['train/copepod_calanoid/', 'train/acantharia_protist', 'train/appendicularian_s_shape', 'train/chaetognath_non_sagitta', 'train/echinoderm_larva_seastar_brachiolaria', 'train/trichodesmium_bowtie', 'train/tunicate_doliolid_nurse']
filepath_list_full = []
filename_list_full = []
 
# iterate over files in directory
for directory in directory_list:

    filepath_list_temp = []
    filename_list_temp = []

    for filename in os.listdir(directory):
        f = os.path.join(directory, filename)
        # checking if it is a file
        if os.path.isfile(f):
            print(f)
            filepath_list_temp.append(f)
            filename_list_temp.append(filename)
    
    filepath_list_full.append(filepath_list_temp)
    filename_list_full.append(filename_list_temp)

for i in range(len(filepath_list_full)):
    for filepath in filepath_list_full[i]:
    
        # get image
        img = Image.open(filepath)
        
        # get width and height
        width = img.width
        height = img.height

        # find max dimensions
        if (width > max_width):
            max_width = width

        if (height > max_height):
            max_height = height
        
        # display width and height
        print("The height of the image is: ", height)
        print("The width of the image is: ", width)
        print("Max height: ", max_height)
        print("Max width: ", max_width)

max_dim = max(max_width, max_height)
print("Max dimension: ", max_dim)

# Save the resulting image
if not os.path.exists("yolov5/datasets/images/train"):
    os.makedirs("yolov5/datasets/images/train")
if not os.path.exists("yolov5/datasets/images/test"):
    os.makedirs("yolov5/datasets/images/test")
if not os.path.exists("yolov5/datasets/images/val"):
    os.makedirs("yolov5/datasets/images/val")
if not os.path.exists("yolov5/datasets/labels/train"):
    os.makedirs("yolov5/datasets/labels/train")
if not os.path.exists("yolov5/datasets/labels/test"):
    os.makedirs("yolov5/datasets/labels/test")
if not os.path.exists("yolov5/datasets/labels/val"):
    os.makedirs("yolov5/datasets/labels/val")

for j in range(len(filename_list_full)):
    for i in range(len(filename_list_full[j])):

        train_num = round(len(filename_list_full[j]) * 0.7)
        test_num = round(len(filename_list_full[j]) * 0.15)
        val_num = round(len(filename_list_full[j]) * 0.15)

        # Create a white image
        white_image = Image.new('RGB', (max_dim, max_dim), 'white')

        # Open the image you want to place in the middle
        image_to_place = Image.open(filepath_list_full[j][i])

        # Calculate the coordinates to place the image in the middle
        x = (white_image.width - image_to_place.width) // 2
        y = (white_image.height - image_to_place.height) // 2

        # Paste the image onto the white image
        white_image.paste(image_to_place, (x, y))

        label_text = str(j) + " "  + str((max_dim/2)/max_dim) + " " + str((max_dim/2)/max_dim) + " " + str(image_to_place.width / max_dim) + " " + str(image_to_place.height / max_dim)

        if i < (train_num):
            white_image.save("yolov5/datasets/images/train/" + str(j) + "_" + filename_list_full[j][i][:-4] + "_cropped.jpg")
            with open("yolov5/datasets/labels/train/" + str(j) + "_" + filename_list_full[j][i][:-4] + "_cropped.txt", "w") as file:
                file.write(label_text)
        
        elif i < (train_num + test_num):
            white_image.save("yolov5/datasets/images/test/" + str(j) + "_" + filename_list_full[j][i][:-4] + "_cropped.jpg")
            with open("yolov5/datasets/labels/test/" + str(j) + "_" + filename_list_full[j][i][:-4] + "_cropped.txt", "w") as file:
                file.write(label_text)
        
        else:
            white_image.save("yolov5/datasets/images/val/" + str(j) + "_" + filename_list_full[j][i][:-4] + "_cropped.jpg")
            with open("yolov5/datasets/labels/val/" + str(j) + "_" + filename_list_full[j][i][:-4] + "_cropped.txt", "w") as file:
                file.write(label_text)